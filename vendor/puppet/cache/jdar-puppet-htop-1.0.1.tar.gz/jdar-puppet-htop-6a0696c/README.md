# htop Puppet Module for Boxen

Installs htop.

[![Build Status](https://travis-ci.org/boxen/puppet-htop.png?branch=master)](https://travis-ci.org/boxen/puppet-htop)

## Usage

```puppet
include htop
```

## Required Puppet Modules

* `boxen`
