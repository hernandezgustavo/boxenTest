require 'spec_helper'


describe 'osx::terminal::default_profile' do
  let(:facts) { {:boxen_user => 'ilikebees'} }

  it do
    should contain_boxen__osx_defaults('Default Terminal Profile').with_value('Pro')
  end

  describe 'with parameters' do
    let(:params) { {:profile => 'Basic'} }

    it do
      should contain_boxen__osx_defaults('Default Terminal Profile').with({
        :key    => 'Default Window Settings',
        :domain => 'com.apple.Terminal',
        :value  => params[:profile],
        :user   => facts[:boxen_user]
      })
    end
  end

  it do
    should contain_boxen__osx_defaults('Startup Window Settings').with_value('Pro')
  end

  describe 'with parameters' do
    let(:params) { {:profile => 'Basic'} }

    it do
      should contain_boxen__osx_defaults('Startup Window Settings').with({
        :key    => 'Startup Window Settings',
        :domain => 'com.apple.Terminal',
        :value  => params[:profile],
        :user   => facts[:boxen_user]
      })
    end
  end
end
