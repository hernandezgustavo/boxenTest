require 'spec_helper'

describe 'osx::mouse::enable_right_click' do
  let(:facts) { {:boxen_user => 'ilikebees'} }

  it do
    should contain_boxen__osx_defaults('Enable mouse right click').with({
      :key    => 'MouseButtonMode',
      :domain => 'com.apple.driver.appleBluetoothMultitouch.mouse',
      :value  => 'TwoButton',
      :user   => facts[:boxen_user]
    })
  end
end
