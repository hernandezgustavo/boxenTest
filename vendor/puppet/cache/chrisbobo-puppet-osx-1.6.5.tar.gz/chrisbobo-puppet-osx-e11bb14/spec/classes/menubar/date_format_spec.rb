require 'spec_helper'

describe 'osx::menubar::date_format' do
  let(:facts) { {:boxen_user => 'ilikebees'} }

  it do
    should contain_boxen__osx_defaults('Date Format').with_value('EEE MMM d  h:mm a')
  end

  describe 'with parameters' do
    let(:params) { {:date_format => 'h:mm a'} }

    it do
      should contain_boxen__osx_defaults('Date Format').with({
        :key    => 'DateFormat',
        :domain => 'com.apple.menuextra.clock',
        :value  => params[:date_format],
        :user   => facts[:boxen_user]
      })
    end
  end
end
