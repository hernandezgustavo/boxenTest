require 'spec_helper'

require 'spec_helper'

describe 'osx::menubar::show_battery_percentage' do
  let(:facts) { {:boxen_user => 'ilikebees'} }

  it do
    should contain_boxen__osx_defaults('Show Battery Percentage').with({
      :key    => 'ShowPercent',
      :domain => 'com.apple.menuextra.battery',
      :value  => true,
      :user   => facts[:boxen_user]
    })
  end
end
