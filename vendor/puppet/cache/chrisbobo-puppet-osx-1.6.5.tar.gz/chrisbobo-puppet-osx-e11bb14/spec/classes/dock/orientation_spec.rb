require 'spec_helper'

describe 'osx::dock::orientation' do
  let(:facts) { {:boxen_user => 'ilikebees'} }

  it do
    should include_class('osx::dock')
    should contain_boxen__osx_defaults('dock orientation').with_value('left')
  end

  describe 'with parameters' do
    let(:params) { {:orientation => 'bottom'} }

    it 'allows you to pass an orientation' do
      should include_class('osx::dock')

      should contain_boxen__osx_defaults('dock orientation').with({
        :domain => 'com.apple.dock',
        :key    => 'orientation',
        :value  => params[:orientation],
        :user   => facts[:boxen_user]
      })
    end
  end
end
