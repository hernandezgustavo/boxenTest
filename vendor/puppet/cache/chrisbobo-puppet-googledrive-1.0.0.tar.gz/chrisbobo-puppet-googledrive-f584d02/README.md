# Google Drive Puppet Module for Boxen
Install [Google Drive](https://tools.google.com/dlpage/drive/index.html), an easy way to share files
and folders on Mac OS X.

## Usage

```puppet
include googledrive
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
