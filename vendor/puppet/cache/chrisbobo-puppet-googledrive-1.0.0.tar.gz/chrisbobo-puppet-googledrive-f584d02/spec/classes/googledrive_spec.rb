require 'spec_helper'

describe 'googledrive' do
  it do
    should contain_package('Google-Drive').with({
      :provider => 'appdmg',
      :source   => 'https://dl.google.com/drive/installgoogledrive.dmg'
    })
  end
end
