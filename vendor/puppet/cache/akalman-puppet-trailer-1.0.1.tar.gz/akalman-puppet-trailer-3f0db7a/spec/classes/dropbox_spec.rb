require 'spec_helper'

describe 'trailer' do
  it do
    should contain_package('Trailer').with({
      :ensure   => 'installed',
      :provider => 'compressed_app'
    })
  end
end
