# puppet-trailer

This is a puppet module for installing [trailer](http://ptsochantaris.github.io/trailer/)

## Usage

```puppet
include puppet
```

## Heira Config Options

| Option             | Values                                                                                              | Default   |
|--------------------|-----------------------------------------------------------------------------------------------------|-----------|
| `trailer::version` | any version specified as a [release for trailer](https://github.com/ptsochantaris/trailer/releases) | `1.3.7`   |
| `trailer::action`  | one of the following strings: `install`, `uninstall`                                                | `install` |

## Required Puppet Modules

- `boxen`
