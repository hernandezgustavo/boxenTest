# Spectacle Puppet Module for Boxen

## Usage

```puppet
include Spectacle
```

## Required Puppet Modules

* boxen

