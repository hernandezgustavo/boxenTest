# WMWare 6 Fusion Puppet Module for Boxen
Install [WMWare 6 Fusion](https://my.vmware.com/web/vmware/info/slug/desktop_end_user_computing/vmware_fusion/6_0).

## Usage

```puppet
include vmware
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
