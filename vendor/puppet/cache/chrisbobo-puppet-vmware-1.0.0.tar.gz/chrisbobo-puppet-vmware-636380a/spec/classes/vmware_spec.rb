require 'spec_helper'

describe 'vmware' do
  it do
    should contain_package('vmware').with({
      :provider => 'appdmg',
      :source   => 'https://download3.vmware.com/software/fusion/file/VMware-Fusion-6.0.1-1331545.dmg'
    })
  end
end
