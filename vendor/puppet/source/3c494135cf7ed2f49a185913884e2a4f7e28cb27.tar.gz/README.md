# WebStorm

[![Build Status](https://api.travis-ci.org/boxen/puppet-webstorm.png?branch=master)](https://travis-ci.org/boxen/puppet-webstorm) 

Install [WebStorm](http://www.jetbrains.com/webstorm/), a Javascript IDE

## Usage

```puppet
include webstorm
```

## Required Puppet Modules

* `boxen`
