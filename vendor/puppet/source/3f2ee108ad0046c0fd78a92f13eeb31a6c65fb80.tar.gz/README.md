#  SourceGear's DiffMerge Puppet Module for Boxen

## Usage

```puppet
include diffmerge
```

## Required Puppet Modules

None.
